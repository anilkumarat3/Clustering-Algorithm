
CREATE TABLE "HBS"."dbo"."geomtest"
(
id int PRIMARY KEY NOT NULL,
type varchar(50),
geom geometry
)








