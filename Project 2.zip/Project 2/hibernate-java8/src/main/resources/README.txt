Java8-specific Hibernate O/RM functionality has been merged into the hibernate-core module, making this hibernate-java8 module
obsolete.  This module will be removed in Hibernate ORM 6.0.  It is only kept here for various consumers that expect a
static set of artifact names across a number of Hibernate releases. See https://hibernate.atlassian.net/browse/HHH-10883